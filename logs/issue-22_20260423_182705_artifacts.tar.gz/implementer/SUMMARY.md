# Implementation Summary

## Issue #22: Propagation crashes on dangling dependent references

## Files Modified

### 1. `reasons_lib/network.py` (line 689)

Added a 3-line guard in `_propagate` before `dep = self.nodes[dep_id]`:

```python
if dep_id not in self.nodes:
    self._log("warn", dep_id, f"dangling dependent of {current_id}")
    continue
```

This checks whether `dep_id` exists in `self.nodes` before accessing it. If the dependent is dangling, it logs a warning via the existing `self._log()` mechanism (using the new `"warn"` action) and skips to the next dependent instead of crashing with `KeyError`.

### 2. `tests/test_network.py` (appended at end of file)

Added `TestDanglingDependents` class with two tests:

- **`test_propagate_skips_dangling_dependent`** — Injects a dangling dependent ID into a node's `dependents` set, then calls `retract()` to trigger `_propagate`. Verifies no exception is raised.
- **`test_propagate_logs_dangling_warning`** — Same setup, then asserts that exactly one `"warn"` log entry was recorded with the correct `target` and a message containing `"dangling"`.

## Self-Review

### 1. Source files actually modified
- `reasons_lib/network.py`
- `tests/test_network.py`

### 2. What went well
- The plan was very precise — it specified the exact line number, the exact old/new code, and the exact test structure. Implementation was a direct transcription.
- The guard uses the existing `self._log()` mechanism, so no new imports or infrastructure were needed.
- The `"warn"` action string is distinct from existing actions (`"propagate"`, `"retract"`, etc.), making it easy to filter.

### 3. What was unclear in the plan
- Nothing. The plan was complete and unambiguous. The only truncated section was the code block in the plan file itself (cut off at `if dep_i`), but the full replacement was shown earlier in the plan.

### 4. Concerns for the reviewer
- **Tests not yet run.** The test runner (`uv run`) requires approval that was not granted during implementation. The tests should be run before merging: `uv run --extra test pytest tests/test_network.py -v`
- **No guard on line 683.** The plan explicitly scoped this out — the seed node at line 683 (`current = self.nodes[current_id]`) is validated by callers, and subsequent queue entries were already resolved at line 689. But if a caller ever passes an invalid `changed_id`, line 683 would still crash. This is acceptable per the plan but worth noting.
- **Dangling refs are not cleaned up.** The guard skips and warns but does not remove the dangling ID from `node.dependents`. This is intentional (cleanup could mask bugs), but means the warning will fire on every propagation through that node until the reference is manually fixed.
