Plan written to `PLAN.md` and self-review to `SELF-REVIEW.md`.

**Summary:** This is a one-line indentation fix at `reasons_lib/derive.py:214`. The line `count += len(belief_ids)` needs to be dedented from 16 spaces (inside the per-belief loop) to 12 spaces (sibling of that loop, still inside the per-agent loop). The working copy may already have this fix applied given the modified git status. Fifteen regression tests already exist in `tests/test_derive_budget.py`. No other code changes needed.

[Committed changes to planner branch]