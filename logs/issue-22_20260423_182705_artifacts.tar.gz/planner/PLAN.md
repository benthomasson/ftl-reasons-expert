# Plan: Guard `_propagate` against dangling dependent references

**Issue:** #22 — Propagation crashes on dangling dependent references

## Requirements Analysis

### What needs to be built

A defensive guard in `_propagate` (line 689 of `network.py`) so that dangling entries in a node's `dependents` set are skipped with a warning instead of crashing the entire BFS cascade.

### Why

Currently, `self.nodes[dep_id]` at line 689 raises an uncaught `KeyError` if `dep_id` is not in the network. While the codebase carefully guards dependent registration (all 4 add-sites check `if ant_id in self.nodes` before adding), dangling references can still appear through:
- Serialization/deserialization round-trips with inconsistent state
- Future code paths that remove nodes without cleaning up reverse indices
- Bugs in external tooling that manipulates `network.json`

The fix should **skip and warn**, not silently ignore. The invariant is still valuable — a dangling reference is a bug — but it should degrade gracefully rather than crash mid-propagation, leaving the network in a partially-updated state.

### Scope boundaries

- **In scope:** Guard in `_propagate`, warning log entry, test coverage
- **Out of scope:** Auditing all other `self.nodes[]` accesses (line 683 is safe — the seed comes from callers who validate, and subsequent queue entries were already resolved at line 689). No need to add guards to `_compute_truth`, `explain`, etc. — those have separate error characteristics.

## Implementation Steps

### Step 1: Add the dangling-dependent guard in `_propagate`

| File | Line(s) | Change Description |
|------|---------|-------------------|
| `reasons_lib/network.py` | 689 | Insert `if dep_id not in self.nodes:` guard before `dep = self.nodes[dep_id]`. On match, log a warning via `self._log()` with action `"warn"` and continue to the next dependent. |

Specifically, replace:

```python
                dep = self.nodes[dep_id]
```

with:

```python
                if dep_id not in self.nodes:
                    self._log("warn", dep_id, f"dangling dependent of {current_id}")
                    continue

                dep = self.nodes[dep_id]
```

**Decision: Use `self._log` with action `"warn"`, not `warnings.warn()` or `logging.warning()`.** Rationale: The codebase has no `logging` or `warnings` imports. It already has a structured audit trail via `self._log()`. Using the existing mechanism keeps the change minimal and makes dangling references visible in the same log consumers already inspect. The action `"warn"` is distinct from the existing `"propagate"` action, so it's easy to filter for.

**Decision: Skip, don't raise.** A more informative `KeyError` was considered but rejected. The point of this fix is crash-freedom: `_propagate` runs mid-mutation (called from `retract`, `assert_node`, `add_justification`, etc.), and crashing partway through leaves truth values inconsistent. Skipping preserves the BFS cascade for all valid dependents.

### Step 2: Add a test for dangling dependent behavior

| File | Line(s) | Change Description |
|------|---------|-------------------|
| `tests/test_network.py` | end of file | Add a new test class `TestDanglingDependents` with two tests: (1) `_propagate` skips a dangling dependent and completes without error, (2) the warning is recorded in `net.log`. |

Test structure:

```python
class TestDanglingDependents:
    def test_propagate_skips_dangling_dependent(self):
        net = Network()
        net.add_node("a", "premise A")
        # Inject a dangling dependent reference
        net.nodes["a"].dependents.add("nonexistent")
        net.retract("a")  # triggers _propagate — should not crash

    def test_propagate_logs_dangling_warning(self):
        net = Network()
        net.add_node("a", "premise A")
        net.nodes["a"].dependents.add("ghost")
        net.retract("a")
        warnings = [e for e in net.log if e["action"] == "warn"]
        assert len(warnings) == 1
        assert warnings[0]["target"] == "ghost"
        assert "dangling" in warnings[0]["value"]
```

## Key Design Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Guard behavior | Skip + warn (not raise) | Crash-freedom is the goal; partial propagation is worse than skipping one bad edge |
| Warning mechanism | `self._log("warn", ...)` | No new dependencies; consistent with existing audit trail |
| Guard location | Line 689 only | Line 683 is safe (seed validated by callers; queue entries already resolved). Adding unnecessary guards adds noise. |
| Warning message content | Include both the dangling ID and the node that references it | Enough context to debug without inspecting the full network |
| Clean up dangling refs? | No | Out of scope. Automatic cleanup could mask bugs. The warning makes them visible; cleanup is a separate concern. |

## Success Criteria

1. `_propagate` completes without raising `KeyError` when a node's `dependents` set contains an ID not present in `self.nodes`
2. A `"warn"` entry appears in `net.log` identifying the dangling reference and the node that holds it
3. All valid dependents in the same BFS cascade are still propagated correctly (the skip only affects the missing node)
4. All existing tests pass unchanged
5. The 14 gated beliefs (starting with `propagation-is-crash-free`) can be marked IN

---

## Self-Review

### What went well
- The codebase is small and well-structured, making it straightforward to trace all callers of `_propagate` and all mutation sites for `dependents`. The existing guard pattern (`if x in self.nodes`) made the design decision obvious.
- Confirming that nodes are never deleted from `self.nodes` (no `del`, `pop`, or `clear`) clarified that the risk is low today but real for future changes.

### What information was missing
- No visibility into how `network.json` is loaded/deserialized — that's the most likely source of dangling references in practice. A future task could audit the import path.

### What would make this easier next time
- Having the existing test file line count / structure summary upfront would save a round-trip when placing new tests.
