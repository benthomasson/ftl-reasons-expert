Plan written to `workspaces/issue-22/planner/PLAN.md`.

**Summary:** The fix is a 4-line guard at `network.py:689` — check if `dep_id` exists in `self.nodes` before accessing it; if not, log a `"warn"` entry via the existing `self._log()` mechanism and `continue`. Two tests confirm the skip and the warning. No new dependencies, no changes to the `_log` signature, no cleanup of dangling refs (that's a separate concern). The change unblocks 14 gated beliefs.

[Committed changes to planner branch]