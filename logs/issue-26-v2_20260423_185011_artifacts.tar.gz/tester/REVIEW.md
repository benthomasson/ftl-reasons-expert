# QA Report: Nogood ID Collision Fix (Issue #26)

## TEST CASES

### Test file: `tests/test_nogood_id_qa.py` (15 tests, 7 classes)

Tests created alongside the existing test infrastructure at `tests/test_nogood_id.py` (implementer's 21 tests). The QA tests focus on integration, regression, and edge cases not covered by the implementer.

| # | Class | Test | What it validates |
|---|-------|------|-------------------|
| 1 | `TestOriginalBugRegression` | `test_len_based_id_would_collide` | Reproduces the exact issue #26 scenario: delete middle nogood, add new one, verify no collision with existing IDs |
| 2 | `TestOriginalBugRegression` | `test_all_ids_unique_after_multiple_deletions` | Delete 3 of 6 nogoods at various positions, add 3 more, assert all IDs unique |
| 3 | `TestApiEndToEnd` | `test_api_add_nogood_after_delete_via_storage` | User-facing path: add via API, delete directly from SQLite, add via API again |
| 4 | `TestApiEndToEnd` | `test_api_sequential_adds_no_regression` | Normal append-only usage through API still produces sequential IDs |
| 5 | `TestStorageRoundTripWithDeletion` | `test_save_delete_load_add` | Save network, delete nogood from DB, reload, add — counter derives correctly |
| 6 | `TestStorageRoundTripWithDeletion` | `test_multiple_save_load_cycles_with_gaps` | 3 save/load cycles with deletions between — IDs never collide |
| 7 | `TestJsonImportWithGaps` | `test_export_with_gap_import_add` | Import JSON with non-contiguous IDs (001, 010), next add produces 011 |
| 8 | `TestBacktrackingWithNogoodIds` | `test_backtracking_produces_unique_id` | Backtracking-triggered nogood gets unique ID even after full deletion |
| 9 | `TestBacktrackingWithNogoodIds` | `test_nogood_id_stable_during_backtracking_cascade` | Pre-existing gap + backtracking cascade: new ID is still unique |
| 10 | `TestComputeNextNogoodIdIdempotent` | `test_double_call_same_result` | Calling `_compute_next_nogood_id` twice yields same result |
| 11 | `TestComputeNextNogoodIdIdempotent` | `test_call_after_add_nogood` | Recomputing after add_nogood reflects current state |
| 12 | `TestNogoodIdWithNonCanonicalIds` | `test_custom_id_ignored` | Custom IDs like "my-custom-nogood" don't affect counter |
| 13 | `TestNogoodIdWithNonCanonicalIds` | `test_partial_match_ignored` | "nogood-abc" (non-digit suffix) is correctly ignored |
| 14 | `TestNogoodIdWithNonCanonicalIds` | `test_mixed_canonical_and_custom` | Mix of canonical, custom, and agent-prefixed IDs |
| 15 | `TestNogoodIdWithNonCanonicalIds` | `test_nogood_with_leading_zeros` | "nogood-007" parses as 7, next is 8 |

### Test results

```
tests/test_nogood_id_qa.py: 15 passed
tests/test_nogood_id.py:    21 passed (implementer tests)
Full suite:                 426 passed in 1.51s
```

---

## USAGE INSTRUCTIONS FOR USER

### Recording a contradiction (nogood)

When two beliefs cannot both be true, record a contradiction:

```bash
# Record that nodes "a" and "b" contradict each other
uv run reasons nogood a b
```

This will:
1. Create a nogood record with a unique ID (e.g., `nogood-001`)
2. If both nodes are currently IN, trigger backtracking to retract the least-entrenched premise
3. Return which nodes changed truth value

### Viewing nogoods

```bash
uv run reasons status
```

Nogoods appear in the status output with their IDs, affected nodes, and resolution status.

### What the fix changes (for users)

**Before (bug):** If a nogood was deleted (e.g., by direct DB edit or during data cleanup), the next `reasons nogood` command could generate an ID that collides with an existing nogood, corrupting the contradiction history.

**After (fix):** Nogood IDs are derived from a monotonically increasing counter based on `max(existing ID numbers) + 1`. Deletions cannot cause collisions because the counter always advances past the highest existing ID.

### Example: safe workflow after deletion

```bash
# Add some contradictions
uv run reasons nogood a b        # creates nogood-001
uv run reasons nogood c d        # creates nogood-002
uv run reasons nogood e f        # creates nogood-003

# Even if nogood-002 is somehow deleted from the database,
# the next nogood will be nogood-004 (not nogood-003)
uv run reasons nogood g h        # creates nogood-004 (safe)
```

### Python API usage

```python
from reasons_lib import api

api.init_db(db_path="my.db")
api.add_node("claim-a", "The sky is blue", db_path="my.db")
api.add_node("claim-b", "The sky is green", db_path="my.db")

result = api.add_nogood(["claim-a", "claim-b"], db_path="my.db")
print(result)
# {"nogood_id": "nogood-001", "nodes": ["claim-a", "claim-b"],
#  "changed": ["claim-b"], "backtracked_to": "claim-b"}
```

### Common scenarios

| Scenario | Expected behavior |
|----------|-------------------|
| Normal sequential adds | IDs increment: 001, 002, 003, ... |
| Add after deleting middle nogood | Skips past max existing ID |
| Add after deleting all nogoods | Resets to 001 (safe — nothing to collide with) |
| Import from JSON with gaps | Counter picks up from max imported ID |
| Import from beliefs.md | Counter picks up from max imported ID |
| Agent-prefixed IDs (e.g., `agent:nogood-099`) | Ignored by counter — only canonical `nogood-NNN` IDs count |

---

## SELF-REVIEW

1. **What was easy to test?** The core counter logic and deletion scenarios were straightforward — the Network class is well-isolated and easy to construct in tests. The SQLite round-trip tests were also clean thanks to `tmp_path`.

2. **What was hard?** Testing the "full user workflow" required reaching into SQLite directly to simulate deletion, since there's no `delete_nogood` API. This is realistic (users might edit the DB directly) but feels like testing an escape hatch. The markdown import tests required constructing valid beliefs.md strings — the implementer's tests already had good fixtures for this.

3. **What information was missing?** The implementation docs were thorough. One thing I'd have appreciated: whether there's a CLI command or API call to *delete* a nogood. There isn't — deletions only happen via direct DB manipulation or data cleanup, which makes the bug somewhat niche but real.

4. **Any gaps revealed?** No functional gaps. The fix is correct and complete. One design observation: when all nogoods are deleted, the counter resets to 1 (by design, since it's derived from existing data). This means IDs can be reused *across full-deletion boundaries*, but since no existing nogoods remain, no collision is possible. This is documented and acceptable.

---

## Verdict

STATUS: TESTS_PASSED
OPEN_ISSUES: none
