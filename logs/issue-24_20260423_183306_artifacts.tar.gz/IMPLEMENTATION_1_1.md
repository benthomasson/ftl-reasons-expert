# Implementation (Iteration 1, Attempt 1)

## Summary

**4 files modified:**

1. **`reasons_lib/network.py`** — Added `_rebuild_dependents()` (canonical rebuild) and `verify_dependents()` (integrity checker) to the `Network` class
2. **`reasons_lib/storage.py`** — Replaced inline 8-line rebuild loop in `load()` with `network._rebuild_dependents()`
3. **`reasons_lib/import_agent.py`** — Replaced `_fixup_dependents()` body with delegation to `_rebuild_dependents()`; simplified `_update_node_justifications()` from 16 lines to 2 (set justifications + rebuild)
4. **`tests/test_network.py`** — Added `TestDependentsIntegrity` class with 9 tests covering every mutation path, corruption detection, corruption repair, and storage round-trip

**Self-review:**

1. **What went well:** Three copy-pasted rebuild implementations are now one canonical method. The verify/rebuild split follows the plan's "detect, don't auto-heal" principle. Test coverage hits all mutation paths.

2. **What was unclear:** The plan's line numbers didn't match the actual file due to a concurrent change (`_compute_next_nogood_id`), but the methods were placed at the correct logical position.

3. **Reviewer concerns:**
   - `_update_node_justifications` now does a full rebuild per call instead of a targeted update — fine for small networks but could slow down large batch syncs
   - Tests were not executed due to permission restrictions — reviewer should run them
   - `_fixup_dependents` kept as a thin wrapper rather than inlining at call sites, to minimize diff

[Committed changes to implementer branch]