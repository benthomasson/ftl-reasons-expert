# Plan: Fix fragile dependents index denormalization

## PLAN

### Requirements Analysis

**What:** The `Node.dependents` set is a reverse index mapping "which nodes depend on me?" — the inverse of the justification graph. It is never persisted to SQLite and is rebuilt on every `storage.load()`. Between loads, every mutation path must manually keep it in sync, and there is no validation that it is correct.

**Why this matters:** `_propagate()` (network.py:675-702) is the only mechanism for cascading truth value changes through the graph. It walks `current.dependents` to find affected nodes. If `dependents` is stale, propagation silently skips nodes, producing wrong truth values. This is the most dangerous class of bug in a TMS — silent corruption of the belief set.

**Chosen approach: Option 3 — Post-mutation integrity check + computed rebuild helper.**

Rationale for rejecting the other two options:
- **Option 1 (persist to SQLite):** Adding a `dependents` table creates a second source of truth that can itself go stale. The whole point of this fix is to eliminate denormalization, not add more.
- **Option 2 (computed property on every access):** `_propagate()` iterates `dependents` inside a BFS loop. Computing it by scanning all nodes on every access turns O(D) propagation into O(N*D) where N is total nodes. Unacceptable for correctness-critical hot path.

Option 3 adds a `_rebuild_dependents()` method that recomputes the index from justifications (the authoritative source), plus a `verify_dependents()` method that compares the live index against the recomputed one. The verify method is called after every mutation in tests, and can be called in production as a debug/audit tool.

Additionally, we extract the duplicate rebuild logic (currently copy-pasted in `storage.load()`, `import_agent._fixup_dependents()`, and `_update_node_justifications()`) into the single `_rebuild_dependents()` method.

### Implementation Steps

#### Step 1: Add `_rebuild_dependents()` to Network

| File | Line(s) | Change Description |
|------|---------|-------------------|
| `reasons_lib/network.py` | After line 24 (after `__init__`) | Add `_rebuild_dependents(self)` method that clears all `node.dependents` sets, then iterates all nodes and their justifications to reconstruct the reverse index. This is the single canonical implementation of the rebuild logic. |

The method should:
1. Clear every node's `dependents` set
2. For each node, for each justification, add node.id to `self.nodes[ant_id].dependents` for each antecedent, and to `self.nodes[out_id].dependents` for each outlist entry
3. Only add when the referenced node exists in `self.nodes`

#### Step 2: Add `verify_dependents()` to Network

| File | Line(s) | Change Description |
|------|---------|-------------------|
| `reasons_lib/network.py` | After `_rebuild_dependents()` | Add `verify_dependents(self) -> list[str]` that computes a fresh dependents index into a temporary dict, compares it against the live `node.dependents` sets, and returns a list of error strings. Empty list = consistent. |

The method should:
1. Build `expected: dict[str, set[str]]` by scanning all justifications (same logic as rebuild)
2. For each node, compare `self.nodes[nid].dependents` against `expected.get(nid, set())`
3. Report extras (in live but not expected) and missing (in expected but not live) as separate error strings
4. Return the list (empty = valid)

#### Step 3: Use `_rebuild_dependents()` in `storage.load()`

| File | Line(s) | Change Description |
|------|---------|-------------------|
| `reasons_lib/storage.py` | Lines 168-176 | Replace the inline rebuild loop with `network._rebuild_dependents()`. The inline loop currently duplicates the same logic. |

#### Step 4: Use `_rebuild_dependents()` in `import_agent._fixup_dependents()`

| File | Line(s) | Change Description |
|------|---------|-------------------|
| `reasons_lib/import_agent.py` | Lines 29-42 (`_fixup_dependents()`) | Replace body with `network._rebuild_dependents()`. The current function adds without clearing first, which means it only works correctly when called on a freshly loaded network with empty dependents. Using `_rebuild_dependents()` is both simpler and more correct (it clears first). |

#### Step 5: Simplify `_update_node_justifications()` in `import_agent.py`

| File | Line(s) | Change Description |
|------|---------|-------------------|
| `reasons_lib/import_agent.py` | Lines 86-106 | Keep the justification replacement logic, but after replacing justifications, call `network._rebuild_dependents()` instead of manually removing old and adding new dependent entries. This is safe because `_rebuild_dependents()` does a full clear+recompute. |

**Design note:** This trades a targeted O(J) update for a full O(N*J) rebuild. For the current use case (small networks, bulk import operations), this is fine. If profiling ever shows this is a bottleneck, the targeted update can be restored — but it should be followed by a `verify_dependents()` assertion.

#### Step 6: Add tests for `verify_dependents()` and `_rebuild_dependents()`

| File | Line(s) | Change Description |
|------|---------|-------------------|
| `tests/test_network.py` | New test class at end of file | Add `TestDependentsIntegrity` class with: |
| | | 1. `test_verify_after_add_node` — add nodes with justifications, verify clean |
| | | 2. `test_verify_after_retract_restore` — retract and restore, verify clean (retract/assert don't touch dependents — verify they don't need to) |
| | | 3. `test_verify_after_add_justification` — add justification to existing node, verify clean |
| | | 4. `test_verify_after_supersede` — supersede a node, verify clean |
| | | 5. `test_verify_after_challenge_defend` — challenge then defend, verify clean |
| | | 6. `test_verify_after_convert_to_premise` — convert derived to premise, verify clean |
| | | 7. `test_verify_detects_stale_index` — manually corrupt `dependents` (add a bogus entry), verify returns errors |
| | | 8. `test_rebuild_fixes_corruption` — corrupt `dependents`, call `_rebuild_dependents()`, verify clean |
| | | 9. `test_verify_after_storage_round_trip` — save, load, verify clean |

### Key Design Decisions

1. **Verify, don't auto-heal.** `verify_dependents()` reports errors but does not fix them. Auto-healing masks bugs in mutation paths. The caller decides whether to rebuild (in production) or fail (in tests).

2. **Single canonical rebuild.** All three existing rebuild implementations (storage.load, _fixup_dependents, _update_node_justifications) are replaced with calls to `_rebuild_dependents()`. One implementation, one place to fix bugs.

3. **No persistence of dependents.** The index remains derived. The fix is to make it verifiable, not to add another persistence obligation.

4. **No change to mutation paths.** `add_node()`, `add_justification()`, `supersede()`, `challenge()`, `convert_to_premise()` all correctly maintain dependents today. The tests will verify this claim and catch future regressions.

5. **`retract()` and `assert_node()` correctly do NOT update dependents.** These change `truth_value` but not the justification graph structure. The dependent set tracks "which nodes reference me in their justifications" — not "which nodes are currently affected by my truth value." This is correct.

### Success Criteria

1. `network.verify_dependents()` returns `[]` after every mutation operation in the test suite
2. `network.verify_dependents()` correctly detects manually-corrupted dependents sets
3. `network._rebuild_dependents()` can repair a corrupted dependents index
4. The three previously-duplicated rebuild loops are consolidated into one method
5. All existing tests continue to pass
6. `storage.load()` → `verify_dependents()` returns clean after a round-trip

## SELF-REVIEW

1. **What went well:** The codebase is well-structured — every mutation path was identifiable and already maintains dependents correctly. The real risk is future mutations, not existing ones. The plan correctly focuses on detectability rather than trying to fix a bug that doesn't exist yet.

2. **What information was missing:** I couldn't determine whether `_update_node_justifications` is called in tight loops during sync operations. If it is, replacing the targeted update with `_rebuild_dependents()` could cause noticeable slowdowns. The implementer should check call patterns in `_sync_claims()`.

3. **What would make this easier next time:** A count of nodes in a typical production network would help calibrate the performance tradeoff in Step 5. If networks are always <1000 nodes, the full rebuild is fine everywhere. If they can reach 10k+, the targeted update in `_update_node_justifications` should be kept with a verify call instead.
