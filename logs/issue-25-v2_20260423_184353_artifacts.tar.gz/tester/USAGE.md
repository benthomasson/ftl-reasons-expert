# Usage Guide: check-stale with source_deleted detection

## What Changed

`reasons check-stale` now reports nodes whose source files have been deleted from disk, instead of silently skipping them. Previously, a deleted source file was indistinguishable from a fresh one.

## CLI Usage

### Check for stale or deleted sources

```bash
uv run reasons check-stale
```

**All fresh:**
```
All 12 nodes with sources are fresh.
```

**Stale and deleted sources detected:**
```
  DELETED  my-belief-from-old-file
           source: myrepo/removed-module.py

  STALE  my-belief-about-utils
         source: myrepo/utils.py
         hash: a1b2c3d4e5f6g7h8 -> z9y8x7w6v5u4t3s2

2 fresh, 2 STALE (of 4 checked)
```

The command exits with code 1 when any stale/deleted nodes are found, code 0 when all are fresh.

### Typical workflow

1. **Check staleness:**
   ```bash
   uv run reasons check-stale
   ```

2. **If sources are stale (content changed), re-hash to accept the new content:**
   ```bash
   uv run reasons hash-sources --force
   ```

3. **If sources are deleted, retract the beliefs that depended on them:**
   ```bash
   uv run reasons retract my-belief-from-old-file --reason "source file deleted"
   ```

## Python API Usage

### Direct function call

```python
from reasons_lib.network import Network
from reasons_lib.check_stale import check_stale

net = Network()
net.add_node("belief-1", "Some belief", source="myrepo/file.py", source_hash="abc123")

results = check_stale(net, repos={"myrepo": Path("/path/to/myrepo")})

for r in results:
    if r["reason"] == "source_deleted":
        print(f"DELETED: {r['node_id']} (was: {r['source']})")
    elif r["reason"] == "content_changed":
        print(f"STALE: {r['node_id']} hash {r['old_hash']} -> {r['new_hash']}")
```

### Via the API layer

```python
from reasons_lib import api

result = api.check_stale(db_path="reasons.db")
# result = {
#     "stale": [...],      # list of result dicts
#     "checked": 10,       # total IN nodes with source+hash
#     "stale_count": 2,    # len(stale)
# }
```

## Result Dict Shape

Both result variants have the same keys:

| Key | `content_changed` | `source_deleted` |
|-----|-------------------|------------------|
| `node_id` | Node ID | Node ID |
| `old_hash` | Stored hash | Stored hash |
| `new_hash` | Current file hash | `None` |
| `source` | Source string (e.g. `"repo/path"`) | Source string |
| `source_path` | Resolved absolute path | `None` |
| `reason` | `"content_changed"` | `"source_deleted"` |

## Common Scenarios

| Scenario | Result |
|----------|--------|
| Source file unchanged | Not in results (fresh) |
| Source file content changed | `reason: "content_changed"` |
| Source file deleted | `reason: "source_deleted"` |
| Node is OUT | Skipped entirely |
| Node has no `source` | Skipped entirely |
| Node has no `source_hash` | Skipped entirely |
| Empty (0-byte) source file | Hashed normally; not treated as deleted |
