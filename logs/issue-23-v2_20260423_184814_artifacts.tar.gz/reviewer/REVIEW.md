# Code Review: Fix _build_beliefs_section budget inflation (Issue #23)

## FEEDBACK FOR IMPLEMENTER

**Correctness:** The fix is correct. Line 214 (`count += len(belief_ids)`) is now at 12 spaces indentation, making it a sibling of the `for belief_id in belief_ids:` loop (line 211) rather than a child. It still sits inside the outer `for agent_name` loop (line 190), so `count` accumulates `len(belief_ids)` once per agent — exactly the intended semantics.

With 6 beliefs from one agent and budget=20:
- **Before (buggy):** count = 6 * 6 = 36, remaining = max(5, 20-36) = 5
- **After (fixed):** count = 6, remaining = max(5, 20-6) = 14

The implementer's self-review note about missing unit tests is now moot — `test_derive_budget.py` exists with 15 comprehensive tests covering the exact regression, multiple-agent accumulation, edge cases, sampling mode, and the `_build_beliefs_section` function directly.

**No changes required.**

## FEED-FORWARD FOR TESTER

### Key behaviors to test
1. **Core regression:** With N agent beliefs, `count` equals N, not N². Test `test_count_is_linear_not_quadratic` covers this.
2. **Multi-agent accumulation:** Count sums correctly across 2+ agents (tests 2, 13).
3. **Budget floor:** `remaining = max(5, max_beliefs - count)` guarantees locals get at least 5 slots even when agents consume the budget (tests 5, 6, 12).
4. **Sampling mode:** The fix applies equally in `sample=True` mode (test 10).

### Edge cases to consider
- **N=1 agent belief:** N²=N=1, so the bug was invisible — verify the fix doesn't break this (test 3).
- **No agents at all:** Entire budget goes to locals, agent loop is skipped (test 4).
- **No local beliefs:** Agent-only network should not error or produce empty output (test 7).
- **Empty network:** Zero beliefs, no crash (test 8).
- **Derived agent beliefs:** Should be excluded from `in_nodes` so they don't inflate count (test 9).

### Suggested test scenarios
The existing `test_derive_budget.py` already covers all of the above with 15 well-structured tests. The tester should:
1. Run `pytest tests/test_derive_budget.py -v` and confirm all 15 pass.
2. Run the full test suite (`pytest tests/`) to check for regressions.
3. Optionally verify that reverting line 214's indentation (adding 4 spaces) causes tests 1, 2, 10, 13, 14, and 15 to fail, confirming the tests actually detect the bug.

### Areas of concern
- The `test_large_network_budget_correct` test (test 14) asserts `local_count > 5` which is a soft check — it doesn't verify the exact proportional allocation. This is acceptable for a regression test but wouldn't catch more subtle budget distribution bugs.

## SELF-REVIEW

1. **What was easy to review:** The change is a single-line indentation fix. The before/after semantics are unambiguous. The surrounding code is well-structured with clear variable names (`count`, `belief_ids`, `remaining`), making it trivial to verify correctness by reading the loop structure.

2. **What made review difficult:** The git commands were blocked by permission constraints, so I couldn't diff the committed vs. working-tree version or verify the commit history. I relied on reading the current file state and cross-referencing with the plan and self-review. The implementer's self-review was helpful in bridging this gap.

3. **What would make my job easier next time:** Pre-approved read-only git commands (`git diff`, `git show`, `git log`) and test execution (`pytest`) would let me verify both the change delta and test results directly.

4. **What the implementer should know:** The self-review mentioned "no dedicated unit test for `_build_beliefs_section` exists" — but `test_derive_budget.py` does exist with 15 tests, including `test_build_beliefs_section_direct` which calls the function directly. This may have been written by the same implementer session and not noticed in the self-review, or it may have been created separately. Either way, test coverage is solid.

## Verdict

STATUS: APPROVED
OPEN_ISSUES: none
