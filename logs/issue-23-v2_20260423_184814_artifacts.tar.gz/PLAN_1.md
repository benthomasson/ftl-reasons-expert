# Plan (Iteration 1)

Task: ## Bug: _build_beliefs_section inflates belief count per agent

## Problem

In `derive.py`, `_build_beliefs_section` has a bug: `count += len(belief_ids)` is inside the per-belief loop instead of outside it. This inflates the count for each agent, shrinking the non-agent budget below its intended size and distorting proportional token allocation during LLM-driven derivation.

## Impact

This root defect gates **9 derived beliefs** in the knowledge base, including:
- `derive-budget-allocation-is-accurate`
- `derive-pipeline-is-production-ready`
- `all-external-inputs-safely-integrated`
- `system-achieves-full-correctness`

## Suggested fix

Move `count += len(belief_ids)` outside the inner loop so it accumulates once per agent, not once per belief.

## Source

Belief: `derive-agent-count-bug`
Entry: `entries/2026/04/23/reasons_lib-derive.md`

Closes #23

EFFORT LEVEL: MODERATE
Keep plan focused and concise. Cover key design decisions but avoid over-analysis.

Plan written to `PLAN.md` and self-review to `SELF-REVIEW.md`.

**Summary:** This is a one-line indentation fix at `reasons_lib/derive.py:214`. The line `count += len(belief_ids)` needs to be dedented from 16 spaces (inside the per-belief loop) to 12 spaces (sibling of that loop, still inside the per-agent loop). The working copy may already have this fix applied given the modified git status. Fifteen regression tests already exist in `tests/test_derive_budget.py`. No other code changes needed.

[Committed changes to planner branch]