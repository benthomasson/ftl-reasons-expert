# Tester Report: Issue #23 — _build_beliefs_section budget inflation fix

## TEST CASES

### Test file: `tests/test_derive_budget.py` (15 tests)

Tests target `_build_beliefs_section` directly, using synthetic node dicts (no database required for unit tests) plus one integration test via `build_prompt` with a real SQLite database.

#### Core regression (2 tests)
1. **test_six_beliefs_one_agent** — With 6 agent beliefs and budget=20, locals get 15 slots (not the buggy 5). Asserts `local_shown > 5` as the regression guard.
2. **test_count_equals_n_not_n_squared** — With 10 agent beliefs and 50 locals, total agent+local shown stays within budget.

#### Multi-agent accumulation (2 tests)
3. **test_two_agents_accumulate_correctly** — Count sums correctly across 2 agents, leaving correct remainder for locals.
4. **test_three_agents_budget_sums** — Same verification with 3 agents.

#### Budget floor (2 tests)
5. **test_floor_of_five_when_agents_exceed_budget** — 50 agent beliefs, 10 locals, budget=20: agents get 18 slots, locals get floor of 5.
6. **test_floor_applies_with_large_agent_set** — 200 agent beliefs, 10 locals, budget=20: agents get 19 slots, locals get floor of 5.

#### Edge cases (6 tests)
7. **test_single_agent_belief** — N=1 agent belief: bug was invisible (N²=N=1), verify fix doesn't break this case.
8. **test_no_agents** — No agents: entire budget goes to grouped local beliefs.
9. **test_no_local_beliefs** — Agent-only network: no crash, no "Local beliefs" section.
10. **test_empty_network** — Zero beliefs, no crash.
11. **test_empty_network_with_agents** — Agents dict provided but no matching nodes.
12. **test_derived_beliefs_excluded_from_count** — Derived agent beliefs (with justifications) are excluded from `in_nodes`.

#### Sampling mode (2 tests)
13. **test_sample_mode_respects_budget** — Sample mode uses the same corrected budget.
14. **test_sample_mode_deterministic** — Same seed produces identical output.

#### Integration (1 test)
15. **test_build_prompt_budget_correct** — End-to-end through `build_prompt` with a real database: creates agent and local nodes, verifies locals shown is between 5 and 20.

### Results

```
353 passed in 1.19s
```

All 15 new tests pass. All 338 existing tests pass (no regressions).

---

## USAGE INSTRUCTIONS FOR USER

### Running the derive pipeline

The `derive` module builds prompts for an LLM to propose new derived beliefs from existing ones. The bug fix ensures proportional budget allocation works correctly when agent-namespaced beliefs are present.

#### 1. Initialize a reasons database

```bash
uv run reasons init
```

#### 2. Add beliefs (premises and derived)

```bash
# Add base premises
uv run reasons add fact-a "Alpha is true"
uv run reasons add fact-b "Beta is true"

# Add derived belief with SL justification
uv run reasons add derived-ab "Alpha and Beta combined" --sl fact-a,fact-b

# Import beliefs from another agent
uv run reasons import-agent /path/to/agent/reasons.db --name agent-a
```

#### 3. Run derivation

```bash
# Build a derive prompt (prints to stdout for piping to an LLM)
uv run reasons derive

# With budget control (default: 300)
uv run reasons derive --budget 20

# Filter by topic
uv run reasons derive --topic "auth security"

# Use random sampling instead of alphabetical truncation
uv run reasons derive --sample --seed 42
```

#### 4. Accept proposed derivations

After the LLM returns proposals in `### DERIVE` / `### GATE` format:

```bash
# Write proposals to a file for review
# (done automatically by the derive command)

# Accept proposals from a file
uv run reasons accept proposed-derivations.md
```

#### 5. Check the network

```bash
uv run reasons status          # all nodes
uv run reasons show derived-ab # single node details
uv run reasons explain derived-ab  # trace why IN or OUT
```

### What the bug fix changes

**Before (buggy):** With N agent beliefs and budget B, the count inflated to N*N, causing `remaining = max(5, B - N*N)` to almost always hit the floor of 5. This starved local beliefs.

**After (fixed):** Count accumulates correctly as N (once per agent), so `remaining = max(5, B - N)` gives local beliefs their fair share of the budget.

**Example:** 6 agent beliefs, budget=20:
- Before: count=36, remaining=max(5, -16)=5 (locals starved)
- After: count=5 (proportional), remaining=max(5, 15)=15 (locals get fair share)

### Running the tests

```bash
# Run just the budget tests
uv run --extra test pytest tests/test_derive_budget.py -v

# Run all tests
uv run --extra test pytest tests/ -v
```

### Expected output

```
tests/test_derive_budget.py::TestCountLinearNotQuadratic::test_six_beliefs_one_agent PASSED
tests/test_derive_budget.py::TestCountLinearNotQuadratic::test_count_equals_n_not_n_squared PASSED
tests/test_derive_budget.py::TestMultiAgent::test_two_agents_accumulate_correctly PASSED
tests/test_derive_budget.py::TestMultiAgent::test_three_agents_budget_sums PASSED
tests/test_derive_budget.py::TestBudgetFloor::test_floor_of_five_when_agents_exceed_budget PASSED
tests/test_derive_budget.py::TestBudgetFloor::test_floor_applies_with_large_agent_set PASSED
tests/test_derive_budget.py::TestEdgeCases::test_single_agent_belief PASSED
tests/test_derive_budget.py::TestEdgeCases::test_no_agents PASSED
tests/test_derive_budget.py::TestEdgeCases::test_no_local_beliefs PASSED
tests/test_derive_budget.py::TestEdgeCases::test_empty_network PASSED
tests/test_derive_budget.py::TestEdgeCases::test_empty_network_with_agents PASSED
tests/test_derive_budget.py::TestEdgeCases::test_derived_beliefs_excluded_from_count PASSED
tests/test_derive_budget.py::TestSampling::test_sample_mode_respects_budget PASSED
tests/test_derive_budget.py::TestSampling::test_sample_mode_deterministic PASSED
tests/test_derive_budget.py::TestBuildPromptIntegration::test_build_prompt_budget_correct PASSED

15 passed in 0.08s
```

---

## SELF-REVIEW

### 1. What was easy to test?

The `_build_beliefs_section` function is well-suited to unit testing — it takes plain dicts and returns a string. Building synthetic node dicts was straightforward and fast (no database needed for most tests). The output format includes "showing N" in headers, making it easy to extract counts.

### 2. What was hard?

Getting the expected values right required tracing through the proportional budget allocation math carefully. My first attempt had wrong expectations because:
- The `:active` premise nodes were included in `agent_beliefs` (they match `startswith`)
- Proportional allocation (`max(5, int(budget * agent_count / total))`) means agents don't always get all their beliefs shown
- The floor-of-5 only kicks in when agents dominate the ratio heavily enough

### 3. What information would have helped?

- A worked example in the code comments showing the proportional budget math would have saved me from calculating it from scratch.
- The reviewer's note about `test_derive_budget.py` having "15 comprehensive tests" was aspirational — that file didn't exist yet.

### 4. Gaps revealed by testing

No implementation gaps. The fix is correct — a single indentation change. The tests confirm count is linear in N, not quadratic. The proportional budget allocation logic is sound.

---

## Verdict

STATUS: TESTS_PASSED
OPEN_ISSUES: none
