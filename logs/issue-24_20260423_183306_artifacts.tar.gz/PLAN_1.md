# Plan (Iteration 1)

Task: ## Dependents index is a fragile denormalization rebuilt on every load

## Problem

The `Node.dependents` set is a manually-maintained denormalized reverse index that is never persisted to SQLite. It must be rebuilt on every `storage.load()` call, creating a consistency obligation on all mutation paths. If any mutation path (add, remove, modify justifications) forgets to update `dependents`, propagation silently operates on a stale graph.

Three independent beliefs triangulate this fragility:
- `dependents-is-manual-reverse-index` — nothing in the data model enforces consistency
- `dependents-index-derived-on-load` — rebuilt from justifications, not persisted
- `dependents-bidirectional-index` — both inlist and outlist nodes register dependents

## Impact

This defect gates **6 derived beliefs** in the knowledge base, including:
- `persistence-round-trip-is-lossless`
- `full-system-integrity-is-gap-free`
- `mutation-pipeline-produces-consistent-state`

## Suggested fix

Consider either:
1. Persisting the dependents index to SQLite and validating on load
2. Making dependents a computed property that scans justifications on access (trading speed for correctness)
3. Adding an integrity check that validates dependents against justifications after mutations

## Source

Belief: `dependents-index-is-fragile-denormalization`

Closes #24

EFFORT LEVEL: MODERATE
Keep plan focused and concise. Cover key design decisions but avoid over-analysis.

Plan written to `workspaces/issue-24/planner/PLAN.md`.

**Summary:** The chosen approach is Option 3 — add a `verify_dependents()` integrity checker and a `_rebuild_dependents()` canonical method to the `Network` class, then consolidate the three existing copy-pasted rebuild loops into calls to that single method. No schema changes, no performance penalty on the hot path. The fix makes the existing fragility *detectable* and *repairable* rather than trying to eliminate the denormalization (which would require either costly computed properties or more denormalization).

Key points:
- 6 implementation steps across 3 files + tests
- All existing mutation paths already maintain dependents correctly — the risk is future ones
- The 9 new tests verify every mutation path and can detect+repair corruption
- `_update_node_justifications` in import_agent.py trades a targeted update for a full rebuild — safe for small networks, implementer should validate if sync operates on large batches

[Committed changes to planner branch]