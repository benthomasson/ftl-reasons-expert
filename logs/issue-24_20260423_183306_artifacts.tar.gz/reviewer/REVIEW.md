# Code Review: Dependents Index Consolidation

## FEEDBACK FOR IMPLEMENTER

**Correctness: Good.** The core implementation is correct. `_rebuild_dependents()` faithfully replicates the rebuild logic from all three call sites it replaces. `verify_dependents()` uses identical traversal logic to build `expected`, then compares it against live state — the two methods are consistent.

I verified every mutation path in `network.py` against the new `_rebuild_dependents` logic:
- `add_node` (line 112–118): Incremental add of new node's deps. Consistent. ✓
- `retract`/`assert_node`: No structural change to justifications. ✓
- `add_justification` (line 406–411): Incremental add for new justification. Consistent. ✓
- `supersede` (line 374): Incremental add for new outlist entry. Consistent. ✓
- `challenge` (line 484): Incremental add for challenge→target. Consistent. ✓
- `convert_to_premise` (line 568–574): Incremental discard. Consistent. ✓

All incremental updates in mutation methods match what `_rebuild_dependents` would produce. The `verify_dependents()` tests prove this holds across all paths.

**One thing outside this PR's scope but worth noting:** `api.py:_rewrite_dependents()` (line 1344–1361) manually manipulates the dependents index during deduplication. It's doing a targeted rewrite (not a full rebuild), so it doesn't fall into the "copy-pasted rebuild" category this PR fixes. But it IS another place where dependents consistency depends on hand-written logic. A `verify_dependents()` call in the deduplicate tests would close that gap.

**Performance note (acknowledged in plan):** `_update_node_justifications` now does O(N×J) rebuild per call. In `_sync_claims`, this is called in a loop — syncing K changed beliefs costs O(K×N×J) instead of O(K×J). Fine for current use (small networks), but if network size grows, consider reverting to a targeted update or batching rebuilds (one rebuild after the loop instead of per-call).

**No changes required.**

## FEED-FORWARD FOR TESTER

**Key behaviors to test:**
1. `verify_dependents()` returns `[]` after every public mutation method (`add_node`, `retract`, `assert_node`, `add_justification`, `supersede`, `challenge`, `defend`, `convert_to_premise`, `summarize`, `add_nogood`)
2. `_rebuild_dependents()` repairs a corrupted index to match what verify expects
3. Storage round-trip preserves dependents integrity (save → load → verify)
4. Import agent and sync agent maintain dependents integrity

**Edge cases to consider:**
- Justification references a node that doesn't exist in the network (the `if ant_id in self.nodes` guard) — verify no KeyError and no phantom dependents
- Node with multiple justifications referencing overlapping antecedents — dependents should be a set (no duplicates)
- Empty network: `verify_dependents()` on an empty network should return `[]`
- Single premise node: no justifications means no dependents entries
- Self-referential justification (node depends on itself) — pathological but shouldn't crash

**Areas of concern for testing:**
- The tests were not executed by the implementer. Run the full test suite first — any test could have regressed from the refactor.
- The `_rewrite_dependents` path in `api.py` (deduplication) is not covered by the new tests. Consider adding `verify_dependents()` assertions to the existing deduplicate tests if they exist.
- `_update_node_justifications` is called from `_sync_claims` — exercise the sync path and verify dependents afterward.

## SELF-REVIEW

1. **What was easy to review:** The diff is clean and localized. Three scattered implementations → one canonical method is a textbook consolidation. The `verify_dependents` method is simple enough to verify by reading — it computes expected from justifications and diffs against live. The test names clearly describe what each test covers.

2. **What made review harder:** I had to manually trace every mutation method in `network.py` (~450 lines) to verify that the incremental dependent updates match what `_rebuild_dependents` would produce. The implementer could have included a "mutation path audit" in the review summary listing each method and whether its dependent management is correct. Finding `_rewrite_dependents` in `api.py` required grepping — it was not mentioned in the plan or review.

3. **What would help next time:** A grep for `\.dependents\.` in the review summary to confirm all mutation sites were considered. The implementer flagged that tests weren't run — having a CI run attached to the review would remove ambiguity.

4. **For the implementer:** The consolidation is well-executed. The "detect, don't auto-heal" design (verify vs. rebuild as separate methods) is the right call — it lets tests be assertive without adding runtime overhead. In future, when claiming "all mutation paths maintain consistency," include the exhaustive list of paths you checked.

## Verdict

The implementation correctly consolidates three copy-pasted rebuild implementations into one canonical method, adds a verification method, and proves via 9 tests that all mutation paths maintain consistency. The code is correct, the test coverage is thorough (covering all `network.py` mutation paths), and the known tradeoff (full rebuild in `_update_node_justifications`) is documented and acceptable for current scale.

STATUS: APPROVED
OPEN_ISSUES: none
