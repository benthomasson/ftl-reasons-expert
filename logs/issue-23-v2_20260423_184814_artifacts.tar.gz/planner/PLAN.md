# Plan: Fix _build_beliefs_section budget inflation (Issue #23)

## Requirements

### What
Fix a single indentation bug in `_build_beliefs_section` where `count += len(belief_ids)` is indented inside the per-belief loop (`for belief_id in belief_ids:`) instead of being a sibling of that loop. This causes `count` to accumulate `len(belief_ids)` once per belief (N times), inflating it to N² instead of N.

### Why
The inflated count shrinks the non-agent budget via `remaining = max(5, max_beliefs - count)`. With 6 agent beliefs and budget=20, the buggy code computes count=36, giving remaining=max(5,-16)=5 instead of the correct remaining=max(5,14)=14. This starves local beliefs and distorts proportional token allocation during LLM-driven derivation. Nine derived beliefs in the knowledge base are gated by this defect.

## Implementation Steps

### Step 1: Fix the indentation bug

| File | Line(s) | Change Description |
|------|---------|-------------------|
| `reasons_lib/derive.py` | 214 | Dedent `count += len(belief_ids)` by one level (16 → 12 spaces). It must be at the same indentation level as `for belief_id in belief_ids:` (line 211), making it a sibling of the inner loop rather than a child. It stays inside the outer `for agent_name` loop (line 190). |

**Before (buggy, committed version):**
```python
            for belief_id in belief_ids:           # line 211, 12 spaces
                text = agent_beliefs[belief_id]["text"][:120]  # 16 spaces
                lines.append(f"- `{belief_id}`: {text}")       # 16 spaces
                count += len(belief_ids)                        # 16 spaces — BUG
```

**After (fixed):**
```python
            for belief_id in belief_ids:           # line 211, 12 spaces
                text = agent_beliefs[belief_id]["text"][:120]  # 16 spaces
                lines.append(f"- `{belief_id}`: {text}")       # 16 spaces
            count += len(belief_ids)                            # 12 spaces — FIXED
```

This is a one-line, whitespace-only change. No logic changes needed.

### Step 2: Verify with tests

The test file `tests/test_derive_budget.py` already exists with 15 comprehensive tests covering:
- Core regression (linear vs quadratic count) — test 1
- Multiple agents accumulation — tests 2, 13
- Single agent (degenerate case) — test 3
- No agents path — test 4
- Budget boundary conditions — tests 5, 6, 12
- No local beliefs — test 7
- Empty network — test 8
- Derived beliefs excluded — test 9
- Sampling mode — test 10
- Stats correctness — test 11
- Large network — test 14
- Direct `_build_beliefs_section` call — test 15

Run: `python -m pytest tests/test_derive_budget.py -v`

All 15 tests should pass with the fix and fail without it.

### Step 3: Run full test suite

Run: `python -m pytest tests/ -v`

Verify no regressions in existing tests (`test_derive.py`, `test_network.py`, `test_check_stale.py`).

## Key Design Decisions

1. **No additional code changes needed.** The fix is a single dedent. The surrounding logic (proportional budget calculation, `max(5, ...)` floor, sampling path) is correct — only the accumulation placement is wrong.

2. **No new tests needed.** `test_derive_budget.py` already has thorough coverage. The implementer should verify these tests exist and pass, but should not need to write more.

3. **No changes to the `else` branch (non-agent path).** Lines 230+ have separate count logic that is unaffected.

## Success Criteria

1. `count` in `_build_beliefs_section` accumulates linearly with the number of shown agent beliefs (N), not quadratically (N²).
2. All 15 tests in `test_derive_budget.py` pass.
3. Full test suite passes with no regressions.
4. The commit message references "Closes #23".
