# Plan (Iteration 1)

Task: ## Propagation crashes on dangling dependent references

## Problem

In `network.py`, `_propagate` accesses `self.nodes[dep_id]` for every ID in `node.dependents` without a membership check. If a dependent reference is dangling (points to a node that does not exist in the network), this raises an uncaught `KeyError`.

This is currently intentional — a broken invariant means a bug — but it makes propagation fragile. A single inconsistency in the `dependents` index crashes the entire BFS cascade.

## Impact

This root defect gates **14 derived beliefs** in the knowledge base, including:
- `propagation-is-crash-free`
- `tms-core-is-crash-safe`
- `system-operations-never-crash`
- `challenge-defense-is-crash-safe`
- `belief-revision-is-fully-reliable`
- `mutation-pipeline-produces-consistent-state`

## Suggested fix

Add a guard in `_propagate` that either skips missing dependent IDs (with a warning) or raises a more informative error that identifies the dangling reference and the node that holds it.

## Source

Belief: `propagate-assumes-dependents-exist`
Entry: `entries/2026/04/23/reasons_lib-network-_propagate.md`

Closes #22

EFFORT LEVEL: MODERATE
Keep plan focused and concise. Cover key design decisions but avoid over-analysis.

Plan written to `workspaces/issue-22/planner/PLAN.md`.

**Summary:** The fix is a 4-line guard at `network.py:689` — check if `dep_id` exists in `self.nodes` before accessing it; if not, log a `"warn"` entry via the existing `self._log()` mechanism and `continue`. Two tests confirm the skip and the warning. No new dependencies, no changes to the `_log` signature, no cleanup of dangling refs (that's a separate concern). The change unblocks 14 gated beliefs.

[Committed changes to planner branch]