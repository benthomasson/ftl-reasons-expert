# Implementation Summary: Nogood ID Collision Fix (Issue #26)

## Files Modified

1. **`reasons_lib/network.py`** (+14 lines, -1 line)
   - Added `import re` at module level
   - Added `self._next_nogood_id: int = 1` to `Network.__init__`
   - Added `_compute_next_nogood_id()` method: scans existing nogoods, extracts numeric suffix via `re.fullmatch(r"nogood-(\d+)", ng.id)`, sets counter to `max + 1`. Uses `fullmatch` so prefixed IDs like `agent:nogood-099` are correctly ignored.
   - Replaced `f"nogood-{len(self.nogoods) + 1:03d}"` with `f"nogood-{self._next_nogood_id:03d}"` and added `self._next_nogood_id += 1` after ID generation

2. **`reasons_lib/storage.py`** (+2 lines)
   - Added `network._compute_next_nogood_id()` after the nogoods loading loop in `Storage.load()`

3. **`reasons_lib/api.py`** (+2 lines)
   - Added `net._compute_next_nogood_id()` after the nogoods import loop in `import_json()`

4. **`reasons_lib/import_beliefs.py`** (+2 lines)
   - Added `network._compute_next_nogood_id()` after the nogoods import block in `import_into_network()`

5. **`tests/test_nogood_id.py`** (new, 369 lines)
   - 20 tests across 6 test classes covering:
     - Core counter derivation (empty, single, gaps, prefixed IDs, large numbers)
     - Deletion + re-add scenarios (the original bug: delete middle, delete last, delete all, normal sequential)
     - SQLite round-trip (save/load/add, save with gaps)
     - JSON import round-trip (export/import/add, counter verification)
     - Markdown import (with nogoods, without nogoods, multiple adds after import)
     - Formatting edge cases (3-digit padding, 4-digit overflow, monotonic increment)

## Self-Review

### 1. What went well
- The plan was precise — every file, line number, and change was correct. Implementation was mechanical.
- The fix is minimal: 4 files touched, ~20 lines of production code changed. No schema migration needed.
- The `re.fullmatch` approach correctly ignores agent-prefixed nogood IDs (e.g., `agent:nogood-099`) without special-case logic.
- Test coverage is thorough — the core bug, all three load paths, and edge cases are all covered.

### 2. What was unclear in the plan
- Nothing was unclear. The plan specified exact file paths, line numbers, and code changes. The planner had already verified the approach against the main repo's existing implementation.

### 3. Concerns for the reviewer
- **`import_agent.py` not patched**: This file also appends to `network.nogoods`, but its IDs are always prefixed (e.g., `agent:nogood-001`), so `_compute_next_nogood_id()` with `fullmatch` intentionally ignores them. No call needed there. However, if agent import ever creates unprefixed nogoods, this would need revisiting.
- **Counter resets on full deletion**: If all nogoods are deleted and `_compute_next_nogood_id()` is called, the counter resets to 1. This is by design (derive-on-load, not persisted), and is safe because no collisions are possible with an empty list. Documented in test `test_delete_all_then_add`.
- **Tests could not be run**: The sandbox environment blocked `pytest` execution. The tests match the pattern from the main repo's existing `test_nogood_id.py` and should pass, but this needs verification.
