# Test Results: check_stale reports missing source files (Issue #25)

## Test File

`tests/test_check_stale_issue25.py` — 15 test cases across 4 test classes.

## Test Cases

### TestSourceDeletedResult (3 tests)

| # | Test | What it validates |
|---|------|-------------------|
| 1 | `test_missing_source_returns_source_deleted` | Node with nonexistent source file produces result with `reason="source_deleted"`, `new_hash=None`, `source_path=None` |
| 2 | `test_source_deleted_has_all_required_keys` | Result dict contains exactly the 6 required keys |
| 3 | `test_content_changed_has_same_keys_as_source_deleted` | Both result variants have identical key sets (uniform shape) |

### TestMixedResults (2 tests)

| # | Test | What it validates |
|---|------|-------------------|
| 4 | `test_mixed_deleted_and_changed` | A single run with deleted, changed, and fresh nodes produces correct reasons for each; fresh node is excluded |
| 5 | `test_multiple_nodes_same_deleted_source` | Two nodes pointing to the same deleted file both appear as `source_deleted` |

### TestSkipBehavior (4 tests)

| # | Test | What it validates |
|---|------|-------------------|
| 6 | `test_skips_out_nodes_with_missing_source` | OUT nodes with deleted sources are not reported (only IN nodes are checked) |
| 7 | `test_skips_nodes_without_source` | Nodes with no `source` field produce no results |
| 8 | `test_skips_nodes_without_hash` | Nodes with `source` but no `source_hash` produce no results |
| 9 | `test_skips_nodes_with_empty_source_string` | Nodes with `source=""` produce no results |

### TestEdgeCases (6 tests)

| # | Test | What it validates |
|---|------|-------------------|
| 10 | `test_empty_file_is_not_deleted` | A 0-byte file with matching hash is fresh, not deleted |
| 11 | `test_empty_file_with_wrong_hash_is_content_changed` | A 0-byte file with wrong hash is `content_changed`, not deleted |
| 12 | `test_no_repos_mapping_with_missing_file` | `repos=None` with nonexistent default path still produces `source_deleted` |
| 13 | `test_fresh_node_not_in_results` | Unchanged files produce no results |
| 14 | `test_results_sorted_by_node_id` | Results are returned in alphabetical node_id order |
| 15 | `test_content_changed_populates_source_path` | Changed-source results contain the resolved file path as a string |

## Run Results

```
15 passed in 0.03s
```

Existing test suite (`tests/test_check_stale.py`): 17 passed, no regressions.
