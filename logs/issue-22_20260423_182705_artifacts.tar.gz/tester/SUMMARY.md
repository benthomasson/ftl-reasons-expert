# Test Summary: Issue #22 — Dangling Dependent Guard

## TEST CASES

Created `tests/test_dangling_dependents.py` with 18 tests across 4 classes:

### TestDanglingDependentNoCrash (4 tests)
1. **test_retract_with_single_dangling_dependent** — retract a node with one dangling ref, no crash
2. **test_assert_with_single_dangling_dependent** — assert_node path with dangling ref, no crash
3. **test_multiple_dangling_refs_on_one_node** — three dangling refs on one node, no crash
4. **test_dangling_ref_alongside_valid_dependent** — valid dependent still propagates to OUT

### TestDanglingDependentWarningLogs (5 tests)
5. **test_single_warning_logged** — exactly one warn entry with correct target and "dangling" text
6. **test_warning_includes_parent_node_id** — warning value names the parent node
7. **test_multiple_dangling_produce_multiple_warnings** — two ghosts produce two warnings
8. **test_warning_on_assert_path** — assert_node (not just retract) fires the warning
9. **test_warning_has_timestamp** — warn log entry includes a timestamp

### TestDanglingDependentPropagationContinues (4 tests)
10. **test_valid_dependent_still_retracted** — dangling ref doesn't block retraction cascade
11. **test_valid_dependent_still_restored** — dangling ref doesn't block restoration via assert
12. **test_chain_with_dangling_in_middle** — A→B→C chain, B has dangling ref, C still updates
13. **test_diamond_with_dangling** — diamond dependency with dangling on root, all nodes update correctly

### TestDanglingDependentEdgeCases (4 tests)
14. **test_same_dangling_in_multiple_nodes** — same ghost ID in two nodes' dependents
15. **test_dangling_not_in_changed_list** — ghost never appears in returned changed list
16. **test_challenge_with_dangling** — challenge() triggers _propagate and handles dangling
17. **test_add_justification_with_dangling** — add_justification() path handles dangling
18. **test_dangling_does_not_enter_visited** — ghost isn't marked visited, so adding it later works normally

### Results

```
18 passed in 0.03s
Full suite: 358 passed in 1.23s (no regressions)
```

---

## USAGE INSTRUCTIONS FOR USER

### Running the full test suite

```bash
uv run --extra test pytest tests/ -v
```

### Running only the dangling-dependent tests

```bash
uv run --extra test pytest tests/test_dangling_dependents.py -v
```

### How the guard works

The guard is in `reasons_lib/network.py` inside `_propagate()` (line 689). When BFS visits a node's dependents, it checks whether each dependent ID exists in `self.nodes` before accessing it. If not:

1. A warning is logged via `self._log("warn", dep_id, f"dangling dependent of {current_id}")`
2. The dependent is skipped (`continue`)
3. Propagation continues to the remaining dependents

### Checking for dangling references after operations

After any operation that triggers propagation (`retract`, `assert_node`, `challenge`, `defend`, `add_justification`), you can inspect the log for warnings:

```python
from reasons_lib.network import Network

net = Network()
# ... operations ...

warnings = [e for e in net.log if e["action"] == "warn"]
for w in warnings:
    print(f"Dangling: {w['target']} — {w['value']}")
```

### Via the CLI

```bash
uv run reasons retract SOME_NODE
uv run reasons log  # check for "warn" entries
```

### What warnings mean

A warning like:

```
action=warn  target=ghost  value="dangling dependent of node-a"
```

means `node-a` has `ghost` in its `dependents` set, but `ghost` does not exist as a node in the network. This indicates a data inconsistency — likely from:
- A node that was removed without cleaning up reverse indices
- A serialization/deserialization round-trip with corrupted state
- External tooling that modified `network.json` incorrectly

The warning fires on every propagation through the affected node until the dangling reference is manually removed from the node's `dependents` set.

### Expected behavior

| Scenario | Before fix | After fix |
|----------|-----------|-----------|
| Retract node with dangling dependent | `KeyError` crash | Warning logged, propagation continues |
| Assert node with dangling dependent | `KeyError` crash | Warning logged, propagation continues |
| Challenge node with dangling dependent | `KeyError` crash | Warning logged, propagation continues |
| Valid dependents alongside dangling | Crash blocks all | Valid dependents still updated correctly |

---

## SELF-REVIEW

### 1. What was easy to test? What was hard?

**Easy:** The core behavior (no crash, warning logged) was trivial to test — inject a fake ID into `node.dependents` and trigger propagation. The guard is pure and deterministic, no mocking needed.

**Easy:** Testing all entry points (`retract`, `assert_node`, `challenge`, `add_justification`) — they all funnel through `_propagate`.

**Slightly tricky:** Verifying the "propagation continues past the dangling ref" behavior required setting up dependency chains and checking that downstream nodes still updated. Not hard, but required understanding the SL justification model.

### 2. What information was missing that would have helped?

Nothing critical. The reviewer's feed-forward notes were thorough — they listed exactly which behaviors and edge cases to test. The implementation summary and plan were clear.

### 3. What would make your job easier next time?

The implementer noted "tests not yet run" — if the implementer had run the tests before handing off, I could have focused purely on edge cases rather than also needing to verify basic functionality.

### 4. Any gaps in the implementation that testing revealed?

No gaps. The guard handles all _propagate entry points correctly. The `recompute_all()` path does NOT use `_propagate` (it recomputes directly), so dangling dependents there would be harmless — no `self.nodes[dep_id]` access occurs in that code path.

---

## Verdict

STATUS: TESTS_PASSED
OPEN_ISSUES: none
