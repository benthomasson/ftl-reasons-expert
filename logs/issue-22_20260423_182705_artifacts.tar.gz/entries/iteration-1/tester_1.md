All 18 tests pass, no regressions in the full suite (358 passed). The implementation correctly guards `_propagate` against dangling dependent references across all entry points: `retract`, `assert_node`, `challenge`, and `add_justification`.

## TEST CASES

Created `tests/test_dangling_dependents.py` with 18 tests in 4 classes:

- **NoCrash (4):** Single dangling on retract, single on assert, multiple danglings, dangling alongside valid dependent
- **WarningLogs (5):** Correct log entry, parent ID in message, multiple warnings for multiple ghosts, assert_node path, timestamp present
- **PropagationContinues (4):** Valid dependent still retracts/restores, chain with dangling in middle, diamond dependency with dangling
- **EdgeCases (4):** Same ghost in multiple nodes, ghost not in changed list, challenge path, add_justification path, ghost not marked visited (can become real node later)

## SELF-REVIEW

1. **Easy:** Core no-crash and log behavior. The guard is pure — inject a fake ID, trigger propagation, check results.
2. **Nothing missing** — the reviewer's feed-forward notes listed exactly the right edge cases.
3. **Would help next time:** Implementer running tests before handoff.
4. **No gaps found.** The guard covers all `_propagate` entry points. `recompute_all()` doesn't use `_propagate`, so it's unaffected.

STATUS: TESTS_PASSED
OPEN_ISSUES: none

[Committed changes to tester branch]