# Code Review: check_stale reports missing source files

## FEEDBACK FOR IMPLEMENTER

**Correctness: Good.** The core fix is correct. The `source_deleted` result dict is appended where the bare `continue` was, so deleted-source nodes now appear in results. The `content_changed` branch also gets a `reason` field, giving both branches a uniform shape. The `api.py` passthrough works correctly — `in_with_source` already counted these nodes (they have `source` + `source_hash` + `IN`), so the `checked` counter was always right; it was only the result list that had the gap.

**Result shape uniformity: Clean.** Both branches produce the same keys: `node_id`, `old_hash`, `new_hash`, `source`, `source_path`, `reason`. The `None` values for `source_deleted` are appropriate.

**CLI output: Correct.** The `DELETED` vs `STALE` branching in `cmd_check_stale` is sensible. Using `.get("reason")` for the check is fine since it falls through gracefully.

**Minor observation (not blocking):** The summary line (`f"{fresh} fresh, {result['stale_count']} STALE"`) lumps deleted and content-changed into one count. The implementer noted this. It's acceptable for a summary — splitting it could be a follow-up if users find it confusing.

**No changes needed.**

## FEED-FORWARD FOR TESTER

**Key behaviors to test:**

1. A node with a missing source file produces a result with `reason="source_deleted"`, `new_hash=None`, `source_path=None`
2. A node with a changed source file produces a result with `reason="content_changed"` and populated `new_hash`/`source_path`
3. Fresh nodes still produce no results
4. OUT nodes and nodes without source/hash are still skipped

**Edge cases to consider:**

- A network with BOTH deleted-source and content-changed nodes in the same run — verify both appear in results with correct reasons
- A node whose source resolves but the file is empty (0 bytes) — should hash correctly, not be confused with deletion
- Multiple nodes pointing to the same deleted source file
- CLI output format for each reason type — verify `DELETED` vs `STALE` labels render correctly

**Areas of concern:**

- The `api.py` `checked` count includes deleted-source nodes in the denominator. Verify the `fresh` = `checked - stale_count` arithmetic produces sensible output when all nodes are deleted vs all are stale vs mixed.
- The test file mentioned in the plan (`tests/test_check_stale_issue25.py` with 24 tests) was not created. The existing test coverage in `test_check_stale.py` covers the happy path. Consider whether a mixed-scenario test (deleted + changed in same run) would add value.

## SELF-REVIEW

1. **What was easy to review:** The diff is small and mechanical — three files, each with a single logical change. The result dict shape is documented in the docstring, so verifying consistency between the docstring, implementation, and tests was straightforward.

2. **What made review slightly harder:** Needing to check the `api.py` passthrough layer to verify the `checked` counter behavior. The implementer's self-review correctly identified this as a concern, which saved time.

3. **What would help next time:** Running the tests before submitting. The implementer noted tests weren't run due to permission issues. A green test run is the single most valuable thing for reviewer confidence.

4. **For the implementer:** The self-review was unusually thorough and accurate — it identified the `api.py` counter question and the CLI summary line limitation correctly. This made the review faster. Keep doing that.

## Verdict

STATUS: APPROVED
OPEN_ISSUES: none
