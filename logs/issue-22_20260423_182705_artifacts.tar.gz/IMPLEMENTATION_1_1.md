# Implementation (Iteration 1, Attempt 1)

## Summary

**Files modified:**
1. **`reasons_lib/network.py`** (line 689) — Added a 3-line guard that checks `dep_id not in self.nodes` before accessing it, logs a `"warn"` entry via `self._log()`, and continues to the next dependent.
2. **`tests/test_network.py`** (end of file) — Added `TestDanglingDependents` class with two tests: one confirming no crash, one confirming the warning is logged.

**Self-review:**

1. **What went well:** The plan was precise enough to be a direct transcription. No new imports or infrastructure needed — the existing `self._log()` mechanism handles the warning cleanly.

2. **What was unclear:** Nothing — the plan was complete and unambiguous.

3. **Concerns for the reviewer:**
   - **Tests not yet run** — `uv run` required approval that wasn't granted. Run `uv run --extra test pytest tests/test_network.py -v` before merging.
   - **Line 683 is unguarded** — intentionally scoped out per plan, but a bad `changed_id` from a caller would still crash there.
   - **Dangling refs not cleaned up** — the warning fires on every propagation through the affected node until manually fixed. This is by design (cleanup could mask bugs).

[Committed changes to implementer branch]