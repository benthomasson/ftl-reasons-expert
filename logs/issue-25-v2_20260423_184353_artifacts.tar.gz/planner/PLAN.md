# Plan: check_stale reports missing source files instead of silently skipping

## Requirements Analysis

**Problem:** In the committed version of `check_stale()`, when `resolve_source_path()` returns `None` (source file doesn't exist on disk), the function executes a bare `continue` — the node is silently skipped. This means beliefs derived from deleted source files appear "fresh" when they should be flagged as stale.

**Goal:** When a source file is missing, include the node in the stale results with `reason: "source_deleted"` so callers can distinguish deleted sources from content changes. The existing `content_changed` results should also carry an explicit `reason` field for result shape uniformity.

**Scope:** Three files need changes, plus one new test file. No new dependencies. No schema changes.

## Implementation Steps

### Step 1: Enrich `check_stale()` to report deleted sources

| File | Line(s) | Change Description |
|------|---------|-------------------|
| `reasons_lib/check_stale.py` | 49–55 (docstring) | Update docstring to document the return shape: add `reason`, `source_path` fields, and document the `"source_deleted"` variant with `new_hash=None` |
| `reasons_lib/check_stale.py` | 62–63 (the `if path is None: continue` block) | Instead of bare `continue`, append a result dict: `{"node_id": nid, "old_hash": node.source_hash, "new_hash": None, "source": node.source, "source_path": None, "reason": "source_deleted"}` then continue |
| `reasons_lib/check_stale.py` | 72 (the existing `content_changed` result dict) | Add `"reason": "content_changed"` to the existing result dict so both branches produce uniform result shapes |

**Design decision: Result shape uniformity.** Both `source_deleted` and `content_changed` results use the same dict keys (`node_id`, `old_hash`, `new_hash`, `source`, `source_path`, `reason`). For `source_deleted`: `new_hash=None`, `source_path=None`. For `content_changed`: both are populated. This avoids callers needing to check for key existence.

### Step 2: Update CLI output for deleted sources

| File | Line(s) | Change Description |
|------|---------|-------------------|
| `reasons_lib/cli.py` | 547–549 (the `for item in result["stale"]` loop body) | Branch on `item.get("reason") == "source_deleted"`: print `DELETED  {node_id}` and `source: {source}` (no hash line). For `content_changed`, keep the existing `STALE` + hash output. |

**Design decision: Distinct label.** Use `DELETED` instead of `STALE` in CLI output. The distinction matters because the remediation is different: `STALE` means re-hash after review; `DELETED` means the source is gone and the belief may need retraction.

### Step 3: Update existing tests

| File | Line(s) | Change Description |
|------|---------|-------------------|
| `tests/test_check_stale.py` | 78 (end of `test_stale_node`) | Add assertion: `assert results[0]["reason"] == "content_changed"` |
| `tests/test_check_stale.py` | 100–104 (`test_skips_missing_source_files`) | Rename to `test_reports_missing_source_files`. Change from `assert results == []` to: assert len == 1, assert reason == "source_deleted", assert new_hash is None, assert source_path is None, assert old_hash preserved |

### Step 4: Add comprehensive issue-specific tests

| File | Line(s) | Change Description |
|------|---------|-------------------|
| `tests/test_check_stale_issue25.py` | (new file) | Add test classes covering: (1) `TestDeletedSourceDetection` — 7 tests verifying each field of the deleted-source result dict; (2) `TestResultShape` — 4 tests verifying both result types share the same keys; (3) `TestMixedScenarios` — 4 tests for mixed fresh/changed/deleted, multiple deleted, delete-then-recreate; (4) `TestExclusions` — 3 tests confirming OUT nodes, no-source nodes, and no-hash nodes are NOT reported; (5) `TestAPIPassthrough` — 3 tests through the `api.check_stale()` layer; (6) `TestCLIOutput` — 3 tests verifying `cmd_check_stale` prints DELETED/STALE correctly |

## Key Design Decisions

1. **Report, don't skip.** Missing source = stale. The whole point of staleness detection is to catch drift, and a deleted source is the most extreme form of drift. Decision: report with `reason="source_deleted"`.

2. **Uniform result shape.** Both result types use identical dict keys. This means callers can iterate results without checking for missing keys. The `reason` field discriminates the two cases.

3. **No changes to `resolve_source_path()`.** It correctly returns `None` for missing files. The bug is in `check_stale()` which treats `None` as "skip" instead of "report." Keep the resolver clean.

4. **No changes to `hash_sources()`.** That function's skip-if-missing behavior is correct — you can't hash a file that doesn't exist. Only `check_stale()` needs the change.

5. **No changes to the API layer.** `api.check_stale()` already passes through results from `check_stale()` and counts nodes with `source` and `source_hash`. Deleted-source nodes already count toward `checked` since they have both fields. No API changes needed.

6. **CLI exit code 1 preserved.** The CLI already exits with code 1 when any stale results exist. Deleted sources are stale results, so they correctly trigger the non-zero exit. No change needed.

## Success Criteria

1. `reasons check-stale` reports nodes whose source files have been deleted, with label `DELETED` and reason `source_deleted`
2. Fresh and content-changed nodes continue to work exactly as before
3. All existing tests pass (with the renamed test updated)
4. New tests cover: deleted source detection, result shape uniformity, mixed scenarios, exclusions, API passthrough, CLI output
5. The `checked` count in API results includes deleted-source nodes (they have source + hash)
6. Issue #25 is closeable — the false-negative gap is eliminated
