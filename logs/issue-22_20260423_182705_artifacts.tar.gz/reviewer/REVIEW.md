# Code Review: Issue #22 — Guard `_propagate` against dangling dependents

## FEEDBACK FOR IMPLEMENTER

**The code change itself is correct and well-placed.** The 3-line guard at line 689 correctly checks `dep_id not in self.nodes` before the dictionary access, logs via the existing `self._log()` mechanism, and `continue`s past the dangling entry. The warning message includes both the dangling ID and the parent node, which is actionable.

**The tests are well-structured** — they cover both the "no crash" behavior and the log output, and the setup (injecting a dangling ID directly into `node.dependents`) is the right approach for this kind of invariant-violation test.

**No correctness issues found.** The guard is in the right position (after the `visited` check, before the node access), uses the right action, and the `continue` correctly skips to the next dependent without corrupting the BFS queue.

**One minor note:** The dangling `dep_id` is not added to `visited`, which means if the same dangling ID appears in multiple nodes' `dependents` sets, the warning will fire once per parent node. This is fine — arguably better for diagnostics — but worth being aware of.

**No changes required.**

## FEED-FORWARD FOR TESTER

### Key behaviors to test
1. **No crash on dangling dependent** — retract/assert a node whose `dependents` set contains a nonexistent ID
2. **Warning logged** — verify `action == "warn"`, correct `target`, and `"dangling"` in the value
3. **Propagation continues past dangling ref** — a node with both a dangling dependent AND a valid dependent should still propagate to the valid one

### Edge cases to consider
- **Multiple dangling refs on one node** — should produce multiple warnings and not crash
- **Dangling ref in the middle of a chain** — node A depends on B, B has dangling ref to "ghost" AND valid ref to C. Retract A. C should still update, "ghost" should warn.
- **`assert_node` path** — the tests only exercise `retract()` as the trigger. `assert_node` also calls `_propagate`, verify it handles dangling refs too.
- **Empty dependents set** — baseline: no warnings, no crash (regression guard)

### Areas of concern
- The tests inject the dangling ID manually. Consider whether serialization round-trips (`to_dict` / `from_dict`) could produce or lose dangling refs — this would be a higher-level integration concern.
- The `retract` early-return path (node already OUT) skips `_propagate` entirely, so a dangling ref on an already-OUT node is never encountered via `retract`. This is fine but the tester should be aware.

## SELF-REVIEW

1. **What was easy to review:** The change is small, self-contained, and well-documented by the implementer's summary. The plan-to-code mapping was clear. The existing `_log` API made the warning mechanism obvious.

2. **What made review difficult:** The initial confusion about where the changes live — the implementer's summary says "committed changes to implementer branch" but the changes are in the workspace copy (`workspaces/issue-22/reasons_lib/network.py`), not the main repo. This required extra investigation to locate the actual diff.

3. **What would help next time:** Clearly state where the modified files live (workspace path vs. repo path vs. branch name). If using a workspace copy rather than a git branch, say so explicitly.

4. **For the implementer:** The line numbers in the summary referenced the original file (line 689) which matched the workspace copy but not the main repo (where `_propagate` starts at line 731). This is fine since the workspace is the source of truth, but noting the offset would prevent confusion.

## Verdict

STATUS: APPROVED
OPEN_ISSUES: none
