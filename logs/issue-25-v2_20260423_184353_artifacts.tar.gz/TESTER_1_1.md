# Tester (Iteration 1, Attempt 1)

## Summary

**15 tests written, all passing. No regressions in existing tests.**

### TEST CASES

Tests in `tests/test_check_stale_issue25.py` covering 4 areas:

- **Core fix** (3 tests): Missing source produces `source_deleted` with `new_hash=None`, `source_path=None`, and uniform keys matching `content_changed`
- **Mixed results** (2 tests): Deleted + changed + fresh in one run; multiple nodes sharing the same deleted source
- **Skip behavior** (4 tests): OUT nodes, no source, no hash, empty source string all still skipped correctly
- **Edge cases** (6 tests): Empty (0-byte) files not confused with deletion; `repos=None` fallback; sorted results; `source_path` populated for changed sources

### USAGE INSTRUCTIONS

See `tester/USAGE.md` for full guide. Key points:
- `uv run reasons check-stale` now prints `DELETED` for missing source files and `STALE` for changed content
- Python callers check `result["reason"]` — either `"source_deleted"` or `"content_changed"`
- Both result variants have identical dict keys for uniform handling

### SELF-REVIEW

1. **Easy to test**: `check_stale()` is a pure function — no database needed, just Network + tmp_path files
2. **Missing**: CLI output formatting (`cmd_check_stale`) not tested directly — would need subprocess or capsys
3. **One test bug fixed**: Initial mixed-results test shared a file between "changed" and "fresh" nodes, causing a false failure — fixed by giving each its own file
4. **No gaps found** in the implementation

## Verdict

STATUS: TESTS_PASSED
OPEN_ISSUES: none

[Committed changes to tester branch]