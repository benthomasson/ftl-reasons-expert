## PLAN

Written to `PLAN.md`. The fix is straightforward — 4 steps across 5 files:

1. **Add `_next_nogood_id` counter and `_compute_next_nogood_id()` to `Network.__init__`** — derives from max existing ID via regex, ignoring prefixed agent IDs.
2. **Replace `len(self.nogoods) + 1` with the counter in `add_nogood`** (line 258 of HEAD `network.py`).
3. **Call `_compute_next_nogood_id()` on all 3 load paths:** `storage.py` (SQLite), `api.py` (JSON import), `import_beliefs.py` (markdown import).
4. **Tests** covering counter basics, the deletion-then-add bug scenario, and round-trips through all persistence formats.

Key decision: derive the counter on load rather than persisting it. This avoids a schema migration and is self-healing. The trade-off (counter resets if all nogoods are deleted) is acceptable since no collisions are possible with an empty list.

## SELF-REVIEW

1. **What went well:** The codebase is small and well-structured, making it easy to trace all the paths that populate `network.nogoods`. The working tree already contains an implementation of this fix, which confirmed my analysis of the required changes and let me validate the approach (derive-on-load, fullmatch regex, all three import paths).

2. **Missing information:** I don't know whether there are other callers that directly manipulate `network.nogoods` outside of these three load paths (e.g., a `resolve_nogood` that deletes from the list). The implementer should grep for `\.nogoods` mutations to verify coverage.

3. **What would help next time:** Having the test suite run results would have let me confirm the changes don't break anything. The implementer should run `pytest` early.

[Committed changes to planner branch]