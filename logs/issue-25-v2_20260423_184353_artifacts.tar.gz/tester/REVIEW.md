# Tester Review: check_stale reports missing source files (Issue #25)

## TEST CASES

15 tests in `tests/test_check_stale_issue25.py`, organized in 4 classes:

- **TestSourceDeletedResult** (3): Core fix validation — missing source produces `source_deleted` result with correct shape and uniform keys matching `content_changed`.
- **TestMixedResults** (2): Both deleted and changed sources in a single run; multiple nodes sharing the same deleted source.
- **TestSkipBehavior** (4): OUT nodes, nodes without source, nodes without hash, and empty source strings are all still skipped.
- **TestEdgeCases** (6): Empty files (0-byte) are not confused with deleted; `repos=None` fallback; result ordering; `source_path` population for changed sources.

All 15 new tests pass. All 17 existing `test_check_stale.py` tests pass (no regressions).

## SELF-REVIEW

1. **What was easy to test?** The `check_stale()` function is pure (takes a Network, returns a list of dicts) — no database, no I/O beyond tmp_path files. Test setup is minimal.

2. **What was hard?** Getting the mixed-results test right required separate files for "changed" vs "fresh" nodes — they can't share a file since modifying one makes both stale. Caught this immediately from the first run.

3. **What information was missing?** The CLI output is tested only indirectly through the result dicts. The `cmd_check_stale` function in `cli.py` is not tested here (it would need capsys or subprocess). The reviewer's notes were clear enough to write tests from.

4. **Gaps revealed?** None in the implementation. The fix is clean — the `source_deleted` branch is a single dict append where the bare `continue` was, and the `content_changed` branch just adds one key. The API layer passes results through unchanged, so no additional testing is needed there.

## Verdict

STATUS: TESTS_PASSED
OPEN_ISSUES: none
