Plan written to `workspaces/issue-24/planner/PLAN.md`.

**Summary:** The chosen approach is Option 3 — add a `verify_dependents()` integrity checker and a `_rebuild_dependents()` canonical method to the `Network` class, then consolidate the three existing copy-pasted rebuild loops into calls to that single method. No schema changes, no performance penalty on the hot path. The fix makes the existing fragility *detectable* and *repairable* rather than trying to eliminate the denormalization (which would require either costly computed properties or more denormalization).

Key points:
- 6 implementation steps across 3 files + tests
- All existing mutation paths already maintain dependents correctly — the risk is future ones
- The 9 new tests verify every mutation path and can detect+repair corruption
- `_update_node_justifications` in import_agent.py trades a targeted update for a full rebuild — safe for small networks, implementer should validate if sync operates on large batches

[Committed changes to planner branch]