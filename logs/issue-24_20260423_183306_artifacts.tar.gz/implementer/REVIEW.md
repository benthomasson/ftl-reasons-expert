# Implementation Review

## Files Modified

### 1. `reasons_lib/network.py` (lines 37–80)
Added two new methods to the `Network` class:

- **`_rebuild_dependents(self) -> None`** — Clears all `node.dependents` sets, then iterates every node's justifications to reconstruct the reverse index from scratch. This is now the single canonical rebuild implementation.

- **`verify_dependents(self) -> list[str]`** — Builds an `expected` dependents dict by scanning all justifications, then compares it against the live `node.dependents` sets. Returns a list of error strings describing extras and missing entries. Empty list means consistent.

### 2. `reasons_lib/storage.py` (line 169)
Replaced the 8-line inline rebuild loop in `load()` with a single call to `network._rebuild_dependents()`.

### 3. `reasons_lib/import_agent.py` (lines 29–35, 79–82)
- **`_fixup_dependents()`** — Replaced the 8-line body with delegation to `network._rebuild_dependents()`.
- **`_update_node_justifications()`** — Replaced the 16-line targeted remove-old/add-new loop with: set the new justifications, then call `network._rebuild_dependents()`. This trades a targeted O(J) update for a full O(N*J) rebuild, which is fine for the current use case (small networks, bulk import).

### 4. `tests/test_network.py` (lines 483–604)
Added `TestDependentsIntegrity` class with 9 tests:

| Test | What it verifies |
|------|-----------------|
| `test_verify_after_add_node` | Adding nodes with justifications keeps index clean |
| `test_verify_after_retract_restore` | retract/assert don't corrupt the structural index |
| `test_verify_after_add_justification` | Adding a justification to an existing node stays clean |
| `test_verify_after_supersede` | Supersede (adds outlist entry) stays clean |
| `test_verify_after_challenge_defend` | Challenge + defend cycle stays clean |
| `test_verify_after_convert_to_premise` | Stripping justifications cleans up dependents |
| `test_verify_detects_stale_index` | Manually-corrupted dependents are caught |
| `test_rebuild_fixes_corruption` | `_rebuild_dependents()` repairs corruption |
| `test_verify_after_storage_round_trip` | Save → load → verify is clean |

## Self-Review

### What went well
- The three duplicate rebuild implementations (storage.load, _fixup_dependents, _update_node_justifications) are now consolidated into one canonical method. This was the core value of the change.
- `verify_dependents()` reports both extras and missing entries separately, which gives actionable error messages.
- Tests cover every mutation path in the Network class (add_node, retract, assert_node, add_justification, supersede, challenge, defend, convert_to_premise) plus corruption detection and repair.

### What was unclear in the plan
- The plan mentions `_next_nogood_id` and `_compute_next_nogood_id` which were not in my original read of network.py but appeared in the linter-modified version. These were added by another change (not part of this task) and I preserved them. The plan's line numbers were based on the original file before that change, but the methods were inserted at the correct logical location regardless.

### Concerns for the reviewer

1. **`_update_node_justifications` performance tradeoff.** The plan noted this: replacing the targeted O(J) dependent update with a full `_rebuild_dependents()` call is O(N*J). This is called from `_sync_claims()` which iterates over all claims in a sync operation. For large agent imports (1000+ beliefs), this could be noticeably slower since each updated belief triggers a full rebuild. If this becomes a problem, the targeted update can be restored with a `verify_dependents()` assertion in tests.

2. **Tests could not be executed.** Command execution was blocked by permission restrictions. The test code is syntactically correct and follows the existing test patterns, but has not been verified to pass. Reviewer should run `uv run --extra test pytest tests/test_network.py::TestDependentsIntegrity -v`.

3. **`_fixup_dependents` kept as thin wrapper.** The function is still called from `_import_claims` and `_sync_claims`. Rather than updating all call sites to use `network._rebuild_dependents()` directly, I kept the wrapper to minimize diff size. It could be inlined in a follow-up.
