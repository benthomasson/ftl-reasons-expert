# Task

## Dependents index is a fragile denormalization rebuilt on every load

## Problem

The `Node.dependents` set is a manually-maintained denormalized reverse index that is never persisted to SQLite. It must be rebuilt on every `storage.load()` call, creating a consistency obligation on all mutation paths. If any mutation path (add, remove, modify justifications) forgets to update `dependents`, propagation silently operates on a stale graph.

Three independent beliefs triangulate this fragility:
- `dependents-is-manual-reverse-index` — nothing in the data model enforces consistency
- `dependents-index-derived-on-load` — rebuilt from justifications, not persisted
- `dependents-bidirectional-index` — both inlist and outlist nodes register dependents

## Impact

This defect gates **6 derived beliefs** in the knowledge base, including:
- `persistence-round-trip-is-lossless`
- `full-system-integrity-is-gap-free`
- `mutation-pipeline-produces-consistent-state`

## Suggested fix

Consider either:
1. Persisting the dependents index to SQLite and validating on load
2. Making dependents a computed property that scans justifications on access (trading speed for correctness)
3. Adding an integrity check that validates dependents against justifications after mutations

## Source

Belief: `dependents-index-is-fragile-denormalization`

Closes #24

Started: 2026-04-23T18:19:58.813931