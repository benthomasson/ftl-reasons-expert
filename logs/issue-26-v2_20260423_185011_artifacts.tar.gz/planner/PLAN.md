# Plan: Fix Nogood ID Collisions After Deletion (Issue #26)

## Requirements

**Bug:** `add_nogood` in `network.py` generates IDs via `len(self.nogoods) + 1`. If a nogood is deleted from the list, the next `add_nogood` call reuses an existing ID, corrupting the contradiction history.

**Fix:** Replace the length-based derivation with a monotonically increasing counter (`_next_nogood_id`) that is recomputed from the max existing ID on load. This must be wired into all entry points that populate `network.nogoods`: SQLite load, JSON import, and markdown import.

**Scope:** The fix is narrow. No schema changes. No new dependencies. The counter is derived on load (not persisted as a separate column), so it's zero-migration.

## Implementation Steps

### Step 1: Add counter and computation method to Network

| File | Line(s) | Change |
|------|---------|--------|
| `reasons_lib/network.py` | 23 (after `self.nogoods`) | Add `self._next_nogood_id: int = 1` to `__init__` |
| `reasons_lib/network.py` | 10 (imports) | Add `import re` |
| `reasons_lib/network.py` | after `__init__` | Add `_compute_next_nogood_id()` method: scan `self.nogoods`, extract numeric suffix via `re.fullmatch(r"nogood-(\d+)", ng.id)`, set counter to `max + 1`. Uses `fullmatch` so prefixed IDs like `agent:nogood-099` are ignored. |

### Step 2: Use the counter in add_nogood

| File | Line(s) | Change |
|------|---------|--------|
| `reasons_lib/network.py` | 258 (HEAD) | Replace `f"nogood-{len(self.nogoods) + 1:03d}"` with `f"nogood-{self._next_nogood_id:03d}"` |
| `reasons_lib/network.py` | after above | Add `self._next_nogood_id += 1` |

### Step 3: Call `_compute_next_nogood_id()` on every load path

| File | Line(s) | Change |
|------|---------|--------|
| `reasons_lib/storage.py` | ~182 (after nogoods loop) | Add `network._compute_next_nogood_id()` after loading nogoods from SQLite |
| `reasons_lib/api.py` | ~936 (after nogoods import loop in `import_json`) | Add `net._compute_next_nogood_id()` after importing nogoods from JSON |
| `reasons_lib/import_beliefs.py` | ~243 (after nogoods import in `import_into_network`) | Add `network._compute_next_nogood_id()` after importing nogoods from markdown |

### Step 4: Tests

Add tests to `tests/test_network.py` (preferred) or a new `tests/test_nogood_id.py`:

1. **Counter basics:** empty list yields 1; single nogood yields 2; gap (001, 005) yields 6; prefixed IDs ignored.
2. **Core bug scenario:** create 3 nogoods, delete the middle one, recompute, add a new one — verify it gets ID 004, not 003.
3. **SQLite round-trip:** save network with nogoods, reload, add new nogood — verify no collision.
4. **JSON import round-trip:** export, import into fresh DB, add nogood — verify counter continuity.
5. **Markdown import:** import beliefs.md with a nogood-005, add new nogood — verify it gets 006.

## Key Design Decisions

1. **Derive-on-load, not persist:** The counter is recomputed from `max(existing IDs) + 1` each time the network is loaded, rather than stored as a separate column. This avoids a schema migration and makes the system self-healing — even hand-edited or corrupted data gets the right counter. Trade-off: if all nogoods are deleted, the counter resets to 1 (acceptable — no collisions possible since there are no existing IDs to collide with).

2. **`re.fullmatch` over `re.match`:** Uses `fullmatch` so that prefixed IDs from agent imports (e.g., `agent:nogood-099`) don't inflate the counter. Only IDs matching the exact `nogood-NNN` pattern contribute.

3. **`:03d` formatting preserved:** IDs continue to be zero-padded to 3 digits (e.g., `nogood-001`) for visual consistency, but the format string naturally handles numbers >= 1000 (e.g., `nogood-1000`).

4. **No UUID approach:** UUIDs would also solve uniqueness but break the human-readable sequential naming that's used throughout the codebase (in `nogoods.md`, entry files, etc.). The counter approach maintains readability.

## Success Criteria

- `add_nogood` produces unique IDs regardless of prior deletions
- Existing networks load correctly with the counter derived from persisted data
- All three import paths (SQLite, JSON, markdown) set the counter correctly
- No schema migration required
- Existing tests continue to pass
