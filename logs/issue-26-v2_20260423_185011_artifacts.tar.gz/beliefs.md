# Beliefs Registry

## Repos


### plan-1-1 [IN] AXIOM
**Add `_next_nogood_id` counter and `_compute_next_nogood_id()` to `Network.__init__`** — derives from max existing ID via regex, ignoring prefixed agent IDs.
- Date: 2026-04-23

### plan-1-2 [IN] AXIOM
**Replace `len(self.nogoods) + 1` with the counter in `add_nogood`** (line 258 of HEAD `network.py`).
- Date: 2026-04-23

### plan-1-3 [IN] AXIOM
**Call `_compute_next_nogood_id()` on all 3 load paths:** `storage.py` (SQLite), `api.py` (JSON import), `import_beliefs.py` (markdown import).
- Date: 2026-04-23

### plan-1-4 [IN] AXIOM
**Tests** covering counter basics, the deletion-then-add bug scenario, and round-trips through all persistence formats.
- Date: 2026-04-23

### plan-1-5 [IN] AXIOM
**What went well:** The codebase is small and well-structured, making it easy to trace all the paths that populate `network.nogoods`. The working tree already contains an implementation of this fix, w
- Date: 2026-04-23

### test-1-1 [IN] OBSERVATION
Tests TESTS_PASSED
- Date: 2026-04-23
